INTERAFAS WEB / release 2026.04.07-rc3

Notas rápidas del despliegue
----------------------------
- Se actualizaron recursos del módulo de prensa.
- Se regeneraron documentos públicos de contratación.
- Se corrigió caché de assets en portada.
- El paquete se preparó desde la estación WEBOPS-03.
- Pendiente: eliminar el archivo de respaldo generado antes del rsync final.

Comprobación posterior
----------------------
1. Portada responde 200.
2. /prensa.php carga recursos.
3. /assets/docs/public/ entrega los documentos vigentes.
4. Pago y Mi Portal conservan sesión.
5. Revisar que no queden artefactos .zip, .bak o .old bajo el document root.
